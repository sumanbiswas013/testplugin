=== Custom top bar ===
Contributors: sumanbiswas013
Donate link: 
Tags: top bar, customize header bar,social links,bar,colorfull topbar,hide admin bar,
Requires at least: 3.0.1
Tested up to: 5.5
Stable tag: 5.5
License: later
License URI: 

You can easily customize page top bar with background color,contact number social links and a custom buttom

== Description ==

You can easily customize page top bar with background color,contact number social links and a custom button

By this plugin you can add / modify your social links with image.
This social links will be display in top bar section.

You can easily enable / disable the top bar from back end.
You can customize the background color.
You can show / hide contact number.
You can show / hide email address.
You can show / hide contact number.
You can show / hide default admin bar.


== Installation ==

1. Upload `top-bar.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==

1.How can I change top bar color ?

After active the plugin admin will get a new menu item. It's name Top Bar Section. From this section admin can add social links and customize the top bar setting.


== Screenshots ==
screenshot-1.png
screenshot-2.png
screenshot-3.png

== Changelog ==


== A brief Markdown Example ==